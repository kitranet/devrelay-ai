"""Business logic layer."""
