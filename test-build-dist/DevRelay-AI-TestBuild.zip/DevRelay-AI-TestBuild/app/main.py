"""ASGI application entry point."""

from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.api.routes import health
from app.api.routes import inference
from app.api.routes import handoffs
from app.api.routes import proposals
from app.api.routes import repositories
from app.api.routes import reviews
from app.api.routes import runtime_validation
from app.api.routes import tasks
from app.core.config import get_settings
from app.core.logging import configure_logging
from app.core.errors import register_exception_handlers
from app.core.config import Settings
from app.services.repository_analysis import RepositoryScanner
from app.services.inference import build_inference_service
from app.services.proposal_store import InMemoryHandoffStore, InMemoryProposalStore, InMemoryReviewStore, InMemoryRuntimeValidationStore, InMemoryTaskPlanStore
from app.services.runtime_validation import UnavailableSandboxExecutor
from app.services.inference_quota import SQLiteInferenceQuota
from app.services.inference_pricing import PricingRegistry
from app.services.inference_telemetry import SQLiteInferenceTelemetry


@asynccontextmanager
async def lifespan(_: FastAPI):
    settings = get_settings()
    configure_logging(settings.log_level)
    yield


def create_app(settings: Settings | None = None) -> FastAPI:
    configured_settings = settings or get_settings()
    application = FastAPI(
        title="DevRelay AI API",
        version="0.1.0",
        description="Backend foundation for engineering handoffs.",
        lifespan=lifespan,
    )
    register_exception_handlers(application)
    application.state.repository_scanner = RepositoryScanner(configured_settings)
    quota = SQLiteInferenceQuota(
        configured_settings.nebius_quota_db_path,
        configured_settings.nebius_total_inference_quota,
    )
    application.state.inference_quota = quota
    telemetry = SQLiteInferenceTelemetry(
        configured_settings.inference_telemetry_db_path,
        PricingRegistry(configured_settings.inference_pricing_overrides_json),
        configured_settings.inference_telemetry_retention_days,
    )
    application.state.inference_telemetry = telemetry
    application.state.inference_service = build_inference_service(configured_settings, quota=quota, telemetry=telemetry)
    application.state.task_plan_store = InMemoryTaskPlanStore()
    application.state.proposal_store = InMemoryProposalStore()
    application.state.review_store = InMemoryReviewStore()
    application.state.handoff_store = InMemoryHandoffStore()
    application.state.runtime_validation_store = InMemoryRuntimeValidationStore()
    application.state.runtime_validation_executor = UnavailableSandboxExecutor()
    application.state.settings = configured_settings
    application.include_router(health.router)
    application.include_router(inference.router)
    application.include_router(repositories.router)
    application.include_router(tasks.router)
    application.include_router(proposals.router)
    application.include_router(reviews.router)
    application.include_router(handoffs.router)
    application.include_router(runtime_validation.router)
    return application


app = create_app()
